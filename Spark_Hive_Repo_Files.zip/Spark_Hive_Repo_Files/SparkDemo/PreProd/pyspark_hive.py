from pyspark.sql.functions import lit,unix_timestamp
from pyspark.sql.types import ArrayType, StringType
from pyspark.sql.functions import *
from pyspark.sql import functions as f
from pyspark.sql import SQLContext
from pyspark.sql.functions import *
from pyspark.sql.functions import col, array_contains
import pyspark
from pyspark import SparkContext
from pyspark.sql.session import SparkSession
from pyspark.sql import Row
from pyspark.sql.functions import udf, size
import sys
from pyspark_llap import HiveWarehouseSession
from pyspark.context import SparkContext
from pyspark.sql import *
from pyspark.sql import SparkSession
from pyspark_llap import HiveWarehouseSession
spark = SparkSession.builder.appName("SparkPipeline").getOrCreate()
hive = HiveWarehouseSession.session(spark).build()
from_db=sys.argv[1]
to_db=sys.argv[2]

print("*************************database_NAME***************",sys.argv[1])
hive.setDatabase("{}".format(from_db))
data1 = hive.executeQuery("select * from sampledata1")
data2 = hive.executeQuery("select job_title ,count(year) as t from sampledata1  group by job_title order by t")
data3 = hive.executeQuery("SELECT  year, count(job_title)as job,worksite as location from  sampledata1 where job_title='DATA ENGINEER' group by year,worksite order by  job desc,year desc")

data4 = hive.executeQuery("select worksite,count(case_status) as t,year from sampledata1 where year ='2011' and case_status='CERTIFIED' group by worksite,year order by t desc")

data5 = hive.executeQuery("select employer_name,count(job_title) as worktitle,job_title from  sampledata1 where job_title = 'DATA SCIENTIST' group by employer_name,job_title order by worktitle desc")

data6 = hive.executeQuery("select employer_name,count(case_status) as petitions from  sampledata1 where year=2016 group by employer_name order by petitions desc")

hive.setDatabase("{}".format(to_db))
data1.write.format("com.hortonworks.spark.sql.hive.llap.HiveWarehouseConnector").mode("Append").option("table", "h1b_hivetestllap2").save()

data2.write.format("com.hortonworks.spark.sql.hive.llap.HiveWarehouseConnector").mode("Append").option("table", "DATA_ENGINEER1").save()

data3.write.format("com.hortonworks.spark.sql.hive.llap.HiveWarehouseConnector").mode("Append").option("table", "Us_DATA_ENGINEER1").save()

data4.write.format("com.hortonworks.spark.sql.hive.llap.HiveWarehouseConnector").mode("Append").option("table", "certified_visa_people").save()

data5.write.format("com.hortonworks.spark.sql.hive.llap.HiveWarehouseConnector").mode("Append").option("table", "Data_Scientist").save()

data6.write.format("com.hortonworks.spark.sql.hive.llap.HiveWarehouseConnector").mode("Append").option("table", "employers_yrs_wise").save()
